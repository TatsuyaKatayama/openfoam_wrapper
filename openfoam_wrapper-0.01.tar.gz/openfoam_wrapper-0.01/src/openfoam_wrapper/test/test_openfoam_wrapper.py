
import unittest


class Openfoam_wrapperTestCase(unittest.TestCase):

    def setUp(self):
        pass
        
    def tearDown(self):
        pass
        
    # add some tests here...
    
    #def test_Openfoam_wrapper(self):
        #pass
        
if __name__ == "__main__":
    unittest.main()
    